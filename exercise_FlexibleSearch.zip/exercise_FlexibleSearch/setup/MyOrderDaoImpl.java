/*
 * Copyright (c) 2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
package my.commerce.trainingflexiblesearch.dao.impl;

import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.core.model.user.CustomerModel;
import de.hybris.platform.servicelayer.internal.dao.AbstractItemDao;
import de.hybris.platform.servicelayer.search.FlexibleSearchQuery;
import de.hybris.platform.store.BaseStoreModel;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import my.commerce.trainingflexiblesearch.dao.MyOrderDao;


/**
 * Searches for the last 30 days orders that belong to the customer.
 */
public class MyOrderDaoImpl extends AbstractItemDao implements MyOrderDao
{

	@Override
	public List<OrderModel> getRecentOrdersForCustomer(final CustomerModel customer)
	{
		// Calculate the time period
		final Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		final Date dayStart = cal.getTime(); // current date
		cal.add(Calendar.DATE, -30);
		final Date dayEnd = cal.getTime(); // 30 days back

        // TODO Step 3 • Implement query written in step 2

		// FS query to find the recent 30 days customer orders
		
		// SELECT ...
		
		final String queryString = "SELECT ...

		// 1. Compile a query from this string
		

		// 2. Add the query parameters
		

		// 3. Execute the FS query
		
		
	}

}
