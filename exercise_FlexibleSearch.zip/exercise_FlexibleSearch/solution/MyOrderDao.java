/*
 * Copyright (c) 2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
package my.commerce.trainingflexiblesearch.dao;

import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.core.model.user.CustomerModel;
import de.hybris.platform.servicelayer.internal.dao.Dao;

import java.util.List;


/**
 * Searches for the last 30 days orders that belong to the customer.
 */
public interface MyOrderDao extends Dao
{
	/**
	 * Searches for the last 30 days orders that belong to the <code>customer</code>.
	 *
	 * @param customer
	 *           whose orders are looked at
	 * @return a list of last 30 days orders that the customer has
	 */
	List<OrderModel> getRecentOrdersForCustomer(CustomerModel customer);
}
